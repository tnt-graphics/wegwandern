<div class="">
    <button class="button wpmf_avada_select_pdf" type="button"><?php esc_html_e('Select', 'wpmf') ?></button>
    </div>