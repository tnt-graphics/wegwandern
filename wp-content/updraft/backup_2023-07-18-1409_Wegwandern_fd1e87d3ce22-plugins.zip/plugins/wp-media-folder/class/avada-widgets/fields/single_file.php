<div class="">
    <button class="button wpmf_avada_select_file" type="button"><?php esc_html_e('Select', 'wpmf') ?></button>
    </div>