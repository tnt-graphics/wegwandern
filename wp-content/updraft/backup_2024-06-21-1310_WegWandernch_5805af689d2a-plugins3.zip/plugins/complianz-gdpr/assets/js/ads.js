/*
* This file has nothing to do with ads, but is a trick to check if an adblocker is enabled.
* https://stackoverflow.com/questions/4869154/how-to-detect-adblock-on-my-website
*
* this way, we can warn the user in the cookie scan that an ad blocker is enabled, which would block the functioning of the scan.
*
*
* */
var canRunAds = true;
