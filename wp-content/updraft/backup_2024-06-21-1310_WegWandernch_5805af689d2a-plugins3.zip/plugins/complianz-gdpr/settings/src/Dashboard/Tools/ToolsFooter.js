const ToolsFooter = () => {
	return null;
}
export default ToolsFooter;
