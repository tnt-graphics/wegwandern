<?php

/**
 * Fired when the plugin is uninstalled.
 */

