<?php

namespace Payrexx\Models\Response;

/**
 * Design response class
 *
 * @copyright Payrexx AG
 * @author    Payrexx Development Team <info@payrexx.com>
 * @package   \Payrexx\Models\Response
 */
class Design extends \Payrexx\Models\Request\Design
{
}
