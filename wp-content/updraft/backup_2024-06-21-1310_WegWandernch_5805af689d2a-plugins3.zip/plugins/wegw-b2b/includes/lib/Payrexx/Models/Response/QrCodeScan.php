<?php

namespace Payrexx\Models\Response;

class QrCodeScan extends \Payrexx\Models\Request\QrCodeScan
{
}
