<?php
/**
 * Template Name: testing ad script Template 
 */ 



get_header();
global $post;
$post_thumb        = get_the_post_thumbnail_url( $post->ID, 'full' );
$tourenportal_page = get_field( 'select_tourenportal_page', 'option' );
$tourenportal_id   = url_to_postid( $tourenportal_page );
$current_url       = $post->ID;
$container_cls     = 'container';
if ( $current_url === $tourenportal_id ) {
	$container_cls = 'touren_container';
}
?>

	<main id="primary" class="site-main">
	<div class="touren_container">
		<?php
		while ( have_posts() ) :
			the_post(); ?>
			
			<script type="text/javascript" id="gbadtag" src="https://gbucket.ch/CH/wegwandern/Desktop/DE_wegwandern_ROS_BTF_AllAdFormats.js"></script>
			
			<!-- 994x560 -->
			<div id="div-ad-gds-1280-6">
			<script type="text/javascript">
			gbcallslot1280("div-ad-gds-1280-6", "");
			</script>
			</div>
<?php

the_content();
			//get_template_part( 'template-parts/wanderung-listing', 'page' );

		endwhile; // End of the loop.
		?>
</div>
	</main><!-- #main -->

<?php
// get_sidebar();
get_footer();
