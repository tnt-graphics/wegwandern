<?php
/**
 * Regionen menu
 **/
global $post;
$region_type                = get_field( 'region_type' );
$wanderung_regionen         = get_field( 'wanderung_regionen' );
$reg                        = get_term( $wanderung_regionen );
$wanderung_regionen_url_upd = get_term_link( $reg );
$child_reg                  = get_term_children( $wanderung_regionen, 'wanderregionen' );
$termParent                 = '';
$arr                        = array();
$term_name                  = get_term( $wanderung_regionen )->name;
$count_child_reg            = count( $child_reg );

if ( is_string( $wanderung_regionen_url_upd ) && $wanderung_regionen_url_upd != '' ) {
	$wanderung_regionen_url = $wanderung_regionen_url_upd;
} else {
	$wanderung_regionen_url = '';
}

if ( empty( $child_reg ) ) {
	$term                          = get_term( $wanderung_regionen, 'wanderregionen' );
	$termParent                    = ( $term->parent == 0 ) ? $term : get_term( $term->parent, 'wanderregionen' );
	$wanderung_regionen_url_parent = get_term_link( $termParent );
	$child_reg                     = get_term_children( $termParent->term_id, 'wanderregionen' );
	$count_child_reg               = count( $child_reg );
}
if ( $region_type == 'slider' ) {
	$slider_sub_titel = get_field( 'slider_sub_titel' ); ?>

	<div class="region_teaser_container">
		<h3 class="region_teaser_title"><?php echo __( 'Wanderregion ', 'wegwandern' ); ?><?php echo $term_name; ?><span class="counter-in-region"><?php echo $count_child_reg; ?></span></h3>
		<h6 class="region_teaser_sub__title"><?php echo $slider_sub_titel; ?></h6>
		<div class="region_teaser_wrap owl-carousel">
			<?php if ( ! empty( $child_reg ) ) { ?>

				<?php
				foreach ( $child_reg as $reg ) {
					$reg_img    = get_field( 'region_img', get_term( $reg ) );
					$def_img    = get_template_directory_uri() . '/img/elm_munggae_huettae_winterwandern-350x350.jpg';
					$teaser_img = ( $reg_img ) ? $reg_img['sizes']['region-slider'] : $def_img;
					?>
					<div class="region_teaser_slider">
						<a href="<?php echo get_term_link( $reg ); ?>">
						<div class="single_region_teaser">
							<img class="" src="<?php echo $teaser_img; ?>">
							<div class="reg_name"><h3><?php echo get_term( $reg )->name; ?></h3></div>
						</div>
						</a>
					</div> 
				<?php } ?>
			<?php } ?>
		</div>
	</div>

<?php } ?>

<?php if ( $region_type == 'menu' ) { ?>
	<div class="nav_region">
		<div class="mainNav_region owl-carousel">
		
			<div class="mainNav_item">
			<?php if ( $termParent == '' ) { ?>
				<a href="<?php echo $wanderung_regionen_url; ?>"><?php echo $term_name; ?></a>
				<?php } else { ?>
					<a href="<?php echo $wanderung_regionen_url_parent; ?>"><?php echo $termParent->name; ?></a>
					<?php } ?>
			</div>
			<?php if ( $termParent != '' && $term_name != $termParent->name ) { ?>
				<div class="subNav_region active"><a class="2222" href="<?php echo $wanderung_regionen_url; ?>"><?php echo $term_name; ?></a></div>
				<?php } ?>	
			<?php if ( ! empty( $child_reg ) ) { ?>
				<?php
				foreach ( $child_reg as $reg ) {
					$arr[] =
							array(
								'name' => get_term( $reg )->name,
								'id'   => get_term( $reg )->term_id,
							);

				}
				asort( $arr );
				?>
				<?php foreach ( $arr as $reg ) { ?>
					<?php if ( $reg['name'] != $term_name ) { ?>
					<div class="subNav_region"><a href="<?php echo get_term_link( $reg['id'] ); ?>"><?php echo $reg['name']; ?></a></div>
						<?php
					}
				}
				?>
			<?php } ?>
		</div>
	</div>
<?php } ?>

<?php if ( $region_type == 'menulinks' ) { 
	
	$verlinkungen_auswahlen                = get_field( 'verlinkungen_auswahlen' );
	?>
	<div class="nav_region">
		<div class="mainNav_region owl-carousel">
			<?php foreach ( $verlinkungen_auswahlen as $menulinks ) { ?>
		<div class="subNav_region"><a href="<?php echo get_permalink( $menulinks->ID ) ?>"><?php echo $menulinks->post_title; ?></a></div>
		<?php } ?>
		</div>
	</div>
	<?php } ?>