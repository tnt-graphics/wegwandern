<?php
/**
 * Wanderung Grey Background Section
 */
$wegw_grey_background_section_content = get_field( 'wegw_grey_background_section_content' );
$wegw_grey_background_section_icon    = get_field( 'wegw_grey_background_section_icon' );
$wegw_grey_background_section_color   = get_field( 'wegw_grey_background_section_color' );
?>

<div class="hightlight-wrapper-container">
	<div class='hightlight-wrapper <?php echo $wegw_grey_background_section_color; ?>'>
		<?php echo $wegw_grey_background_section_content; ?>
		<img src="<?php echo $wegw_grey_background_section_icon['url']; ?>" />
	</div>
</div>
