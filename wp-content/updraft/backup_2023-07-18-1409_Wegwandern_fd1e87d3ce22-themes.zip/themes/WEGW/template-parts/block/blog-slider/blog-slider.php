<?php
/**
 * The template for displaying blog slider
 */

$select_post    = get_field( 'select_post' );
$all_blog_count = count( $select_post );
$blogs          = get_field( 'blog' );

?>

<?php if ( $select_post ) { ?>
<div class="container-fluid full-width-slider grey-back">
	<div class="wander-in-region-wrapper ">
	<div class="wander-in-region">
		<h3 class="full-width-slider-title"><?php echo __( 'Aus unserem Blog', 'wegwandern' ); ?><span class="counter-in-region"><?php echo $all_blog_count; ?></span></h3>
		</div>
	<div class="owl-carousel owl-theme wander-in-region-carousel">
		<?php
		foreach ( $select_post as $blog ) {
				$post_thumb = get_the_post_thumbnail_url( $blog['blog']->ID, 'teaser-twocol' );
			?>
		<div class="single-wander">
			<div class="single-wander-img">
			<a href="<?php echo get_the_permalink( $blog['blog']->ID ); ?>">
				<img decoding="async" class="wander-img" src="<?php echo $post_thumb; ?>">
			</a>
			</div>
			<h6>
			<?php // deactivating this for now, it should be dynamic, mabey categroy or tag 			Thema
			?></h6>
			<h3><a href="<?php echo get_the_permalink( $blog['blog']->ID ); ?>"><?php echo $blog['blog']->post_title; ?></a></h3>
			
			</div>
		
		<?php } ?>
		</div>
		</div>
	<a href="<?php echo home_url(); ?>"><div class="wander-in-region-btn region-desktop"><?php echo __( 'Zur Blog Übersicht', 'wegwandern' ); ?></div></a>
	<a href="<?php // echo $cat_link; ?>"><div class="wander-in-region-btn region-tab"><?php echo __( 'Zur Blog Übersicht', 'wegwandern' ); ?></div></a>
	<a href="<?php // echo $cat_link; ?>"><div class="wander-in-region-btn region-mob"><?php echo __( 'Zur Blog Übersicht', 'wegwandern' ); ?></div></a>
	</div>

</div>
<?php } ?>
