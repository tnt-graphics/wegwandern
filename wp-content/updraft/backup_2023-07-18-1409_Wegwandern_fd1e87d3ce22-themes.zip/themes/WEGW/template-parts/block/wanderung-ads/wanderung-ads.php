<?php
/**
 * Wanderung Ads Section
 **/
$desktop_ad_size = get_field( 'desktop_ad' );
$tablet_ad_size  = get_field( 'tablet_ad' );
$mobile_ad_size  = get_field( 'mobile_ad' );

$ads_html          = '';
$desktop_ad_script = '';
$tablet_ad_script  = '';
$mobile_ad_script  = '';
/*
 * Loop ACF `Group` for ads settings
 */
if ( have_rows( 'manage_ad_scripts', 'option' ) ) :
	while ( have_rows( 'manage_ad_scripts', 'option' ) ) :
		the_row();

		/* Get Desktop Ad Script */
		if ( have_rows( 'desktop_ad_scripts' ) ) :
			while ( have_rows( 'desktop_ad_scripts' ) ) :
				the_row();
				$ad_size   = get_sub_field( 'ad_size' );
				$ad_script = get_sub_field( 'ad_script' );

				if ( $ad_size == $desktop_ad_size ) {
					$desktop_ad_script = $ad_script;
				}
			endwhile;
		endif;

		/* Get Tablet Ad Script */
		if ( have_rows( 'tablet_ad_scripts' ) ) :
			while ( have_rows( 'tablet_ad_scripts' ) ) :
				the_row();
				$ad_size   = get_sub_field( 'ad_size' );
				$ad_script = get_sub_field( 'ad_script' );

				if ( $ad_size == $tablet_ad_size ) {
					$tablet_ad_script = $ad_script;
				}
			endwhile;
		endif;

		/* Get Mobile Ad Script */
		if ( have_rows( 'mobile_ad_scripts' ) ) :
			while ( have_rows( 'mobile_ad_scripts' ) ) :
				the_row();
				$ad_size   = get_sub_field( 'ad_size' );
				$ad_script = get_sub_field( 'ad_script' );

				if ( $ad_size == $mobile_ad_size ) {
					$mobile_ad_script = $ad_script;
				}
			endwhile;
		endif;

	endwhile;
endif;

$wandrung_ads_block_classname = isset( $block['className'] ) ? $block['className'] : '';

if ( isset( $desktop_ad_script ) && $desktop_ad_script != '' ) {
	$ads_html .= "<div class='ad-section-wrap " . $wandrung_ads_block_classname . " ad-desktop full-width'><p>Anzeige</p>";
	$ads_html .= "<div class='ad-section ad-desktop'>" . $desktop_ad_script . '</div>';
	$ads_html .= '</div>';
}

if ( isset( $tablet_ad_script ) && $tablet_ad_script != '' ) {
	$ads_html .= "<div class='ad-section-wrap " . $wandrung_ads_block_classname . " ad-tablet full-width'><p>Anzeige</p>";
	$ads_html .= "<div class='ad-section ad-tablet'>" . $tablet_ad_script . '</div>';
	$ads_html .= '</div>';

	/* Ipad Ads section */
	$ads_html .= "<div class='ad-section-wrap " . $wandrung_ads_block_classname . " ad-ipad full-width'><p>Anzeige</p>";
	$ads_html .= "<div class='ad-section ad-ipad'>" . $tablet_ad_script . '</div>';
	$ads_html .= '</div>';
}

if ( isset( $mobile_ad_script ) && $mobile_ad_script != '' ) {
	$ads_html .= "<div class='ad-section-wrap " . $wandrung_ads_block_classname . " ad-mobile full-width'><p>Anzeige</p>";
	$ads_html .= "<div class='ad-section ad-mobile'>" . $mobile_ad_script . '</div>';
	$ads_html .= '</div>';
}

echo $ads_html;
