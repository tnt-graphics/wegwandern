<?php
/**
 * Template for teaser box
 */
global $post;
$titel         = get_field( 'titel' );
$sub_title     = get_field( 'sub_title' );
$teaser_layout = get_field( 'teaser_layout' );

$bild       = get_field( 'bild' );
$count_bild = count( $bild );
$div_outer  = '';
$div_class  = '';
$cat_title  = '';

if ( $count_bild == 3 ) {
	$div_outer  = 'col3_wrap';
	$div_class  = 'col3_natur';
	$t_img_size = 'hike-region';
	$cat_title  = 'kategorie_titel';
} elseif ( $count_bild == 2 ) {
	$div_outer  = 'col2_wrap';
	$div_class  = 'col2_natur';
	$t_img_size = 'teaser-twocol';
	$cat_title  = 'kategorie_titel';
} elseif ( $count_bild == 1 ) {
	$div_outer  = 'col1_wrap';
	$t_img_size = 'teaser-onecol';

}

$layout_class = '';
if ( $teaser_layout == 'background_image' ) {
	$layout_class = 'bgImage';
	$t_img_size   = ( $count_bild == 3 ) ? 'teaser-onecol' : 'teaser-twocol';
} elseif ( $teaser_layout == 'background_image_number' ) {
	$layout_class = 'bgImageNumber';
	$t_img_size   = ( $count_bild == 3 ) ? 'teaser-onecol' : 'teaser-twocol';
	$cat_title    = 'amount';
}

?>

<div class="<?php echo $div_outer; ?> <?php echo $layout_class; ?>">

	<?php
	if ( $count_bild == 1 ) {
		if ( $titel ) {
			?>
			<h3 class="natur_title"> <?php echo $titel; ?></h3>
		<?php } ?>

		<?php if ( $sub_title ) { ?>
			<h6 class="natur_sub__title"><?php echo $sub_title; ?></h6>
		<?php } ?>

		<a href="<?php echo $bild[0]['teaser_link']; ?>" target="_blank"><img class="teaser_img" src="<?php echo $bild[0]['teaser_Image']['sizes'][ $t_img_size ]; ?>">
			<div class="natur-img-content-wrap">
				<p><?php echo $bild[0]['kategorie_titel']; ?></p>
				<h3 class="natur-title"><?php echo $bild[0]['img_titel']; ?></h3>
			</div>
		</a>
	<?php } ?>

	<?php if ( $count_bild == 2 || $count_bild == 3 ) { ?>
	<div class="<?php echo $div_class; ?>">
		<?php
		foreach ( $bild as $teaser ) {
			if ( $teaser_layout == 'background_image' || $teaser_layout == 'background_image_number' ) {
				$cont_html = '<a href="'. $teaser['teaser_link'] .'" target="_blank"><img class="teaser_img" src="'. $teaser['teaser_Image']['sizes'][ $t_img_size ] .'">
								<div class="bgWrap"><h6>' . $teaser[ $cat_title ] . '</h6>
							    <h3>' . $teaser['img_titel'] . '</h3></div></a>';
			} else {
				$cont_html = '<a href="'. $teaser['teaser_link'] .'" target="_blank"><img class="teaser_img" src="'. $teaser['teaser_Image']['sizes'][ $t_img_size ] .'"></a>
							<a class="region-link-wrap" href="' . $teaser['teaser_link'] . '" target="_blank"><h6>' . $teaser[ $cat_title ] . '</h6>
							<h3>' . $teaser['img_titel'] . '</h3></a>';
			}
			?>
		<div class="single_natur">
			
			<?php echo $cont_html; ?>
		</div>
		<?php } ?>
	</div>
	<?php } ?>
	
</div>
