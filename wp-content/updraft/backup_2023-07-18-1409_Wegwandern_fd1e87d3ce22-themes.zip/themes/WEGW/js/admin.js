if (typeof $ === 'undefined') {
    var $ = jQuery;
}

jQuery(document).ready(function () {
  /*Show count in the filter during initial load*/
    wegw_map_filter_results('hover');
    jQuery(".filterMenu .filter_content_wrapper .fc_block_select label input[type=checkbox]").on('change',  function() {
      jQuery(this).parent().toggleClass('active');
      
  });
    /*show only count in filter when checkbox is selected*/
    jQuery('.filterMenu .filter_content_wrapper input[type=checkbox]').on('change', function () {
        wegw_map_filter_results('hover');
    });

    /*keyup event on search field*/
    jQuery(".search input").on("keyup", function (e) {
        /* show/hide close icon in search in menu sidebar  */
          if(jQuery('.navigation_search input').val().length != 0) {
            jQuery('.navigation_search_close').removeClass("hide");
          } else {
            jQuery('.navigation_search_close').addClass("hide");
          }
          /* show/hide close icon in search in header  */
          if(jQuery('.head_navigation_search input').val().length != 0) {
            jQuery('.head_navigation_search_close').removeClass("hide");
          } else {
            jQuery('.head_navigation_search_close').addClass("hide");
          }
          /* show/hide close icon in search in responsive cluster map(tourenportal)  */
          if(jQuery('#map-resp .map_main_search input').val().length != 0) {
            jQuery('#map-resp .map_main_search_close').removeClass("hide");
          } else {
            jQuery('#map-resp .map_main_search_close').addClass("hide");
          }
          /* show/hide close icon in search in desktop cluster map(tourenportal)  */
          if(jQuery('#map_desktop .map_main_search input').val().length != 0) {
            jQuery('#map_desktop .map_main_search_close').removeClass("hide");
          } else {
            jQuery('#map_desktop .map_main_search_close').addClass("hide");
          }
    });

    /*double side slider in the filter sidebar*/
    jQuery(".slider.multi-slide").each(function (i, data) {
        // $this is a reference to .slider in current iteration of each
        var $this = jQuery(this);
        // find any .slider-range element WITHIN scope of $this
        jQuery(".slider-range", $this).slider({
            range: true,
            min: parseInt($this.attr('data-first')),
            max: parseInt($this.attr('data-second')),
            values: [parseInt($this.attr('data-first')), parseInt($this.attr('data-second'))],
            /** change the first and last value while sliding the slider */
            slide: function(event, ui) {
                // find any element with class .amount WITHIN scope of $this
                if($this.attr('data-notation') === 'h'){
                    /**check if two digit no or not for first value*/
                    if(ui.values[0] <= 9){
                        jQuery(".firstVal", $this).val("0"+ ui.values[0]+':00 ' + $this.attr('data-notation'));
                    }else{
                        jQuery(".firstVal", $this).val(ui.values[0]+':00 ' + $this.attr('data-notation'));
                    }
                    /**check if two digit no or not for second value*/
                    if(ui.values[1] <= 9){
                        jQuery(".secondVal", $this).val('> 0'+ui.values[1]+':00 ' + $this.attr('data-notation'));
                    }else{
                        jQuery(".secondVal", $this).val('> '+ui.values[1]+':00 ' + $this.attr('data-notation'));
                    }
                    
                    jQuery($this).attr("data-first", ui.values[0]);
                    jQuery($this).attr("data-second", ui.values[1]);
                    wegw_map_filter_results('hover');
                }else{
                    jQuery(".firstVal", $this).val(ui.values[0] +" "+ $this.attr('data-notation'));
                    jQuery(".secondVal", $this).val(ui.values[1] +" "+ $this.attr('data-notation'));
                    jQuery($this).attr("data-first", ui.values[0]);
                    jQuery($this).attr("data-second", ui.values[1]);
                    wegw_map_filter_results('hover');
                }   
            },
            stop: function(event, ui) {
              wegw_map_filter_results('hover');
            }
        });
      /** change the first and last value based on the slider */
      if($this.attr('data-notation') === 'h'){
        /**check if two digit no or not for first value*/
          if($this.attr('data-first') <= 9){
              jQuery(".firstVal", $this).val("0"+$this.attr('data-first')+':00 ' + $this.attr('data-notation'));
          }else{
              jQuery(".firstVal", $this).val($this.attr('data-first')+':00 ' + $this.attr('data-notation'));
          }
          /**check if two digit no or not for second value*/
          if($this.attr('data-second') <= 9){
                jQuery(".secondVal", $this).val('> 0'+$this.attr('data-second')+':00 ' + $this.attr('data-notation'));
          }else{
                jQuery(".secondVal", $this).val('> '+$this.attr('data-second')+':00 ' + $this.attr('data-notation'));
          }
      }else{
          jQuery(".firstVal", $this).val($this.attr('data-first') + " "+$this.attr('data-notation'));
          jQuery(".secondVal", $this).val($this.attr('data-second') +" "+ $this.attr('data-notation'));
      }
    });

    //loadmore button
    var loadmore = jQuery(".LoadMore");
    if (jQuery(".single-wander-wrappe").length) {
      var wanderung_filter_query = jQuery("#wanderung_filter_query").val();
    }
    // loadmore for hikngs
    jQuery(document).on("click", "#wanderung-loadmore", function () {
      var itemcount = jQuery(".single-wander").length;
      var loc = jQuery(".header_menu .search_head").val();
      var sort = '';
      /** get the sort value large/short */
      if(window.innerWidth < 1200){
        /** sort div for responsive */
          if( jQuery(".ListHead.mob .sort-largest").prop('checked') == true ){
              var sort = 'large'; 
          }
          if( jQuery(".ListHead.mob .sort-shortest").prop('checked') == true ){
              var sort = 'short'; 
          }
      }else{
        /**sort div for desktop */
          if( jQuery(".ListHead .sort-largest").prop('checked') == true ){
              var sort = 'large'; 
          }
          if( jQuery(".ListHead .sort-shortest").prop('checked') == true ){
              var sort = 'short'; 
          }
      }

      jQuery('#loader-icon').removeClass("hide");
      /**loadmore in tourenportal page and region hike page  */
      if (jQuery(".single-wander-wrappe").length || jQuery(".region-single-wander-wrappe").length) {
        var data = generate_data_array(null);
        var mapDragEvent = $('#wanderung-loadmore').data("event");
        var listDiv;

        // if (mapDragEvent == 'dragMap') {
        //   listDiv = $('.single-wander-wrappe');
        //   data['action'] = "wanderung_drag_map_hikes_load_more";
        //   data['filtered_map_ids'] = $('#mapDragFilterHikeId').val();
        // } else if (mapDragEvent == 'regionenMap') {
        //   listDiv = $('.region-single-wander-wrappe');
        //   data['action'] = "wanderung_regionen_map_load_more";
        //   data['regionen_id'] = $('#regionen_id').val();
        // } else {
        //   listDiv = $('.single-wander-wrappe');
        //   data['action'] = "wanderung_load_more";
        // }
        /* Update on 11/07/2023 for intial sort drag map issue */
        if (mapDragEvent == 'regionenMap') {
          listDiv = $('.region-single-wander-wrappe');
          data['action'] = "wanderung_regionen_map_load_more";
          data['regionen_id'] = $('#regionen_id').val();
        } else {
          listDiv = $('.single-wander-wrappe');
          data['action'] = "wanderung_drag_map_hikes_load_more";
          data['filtered_map_ids'] = $('#mapDragFilterHikeId').val();
        }

        data['nonce'] = ajax_object.ajax_nonce;
        data['sort'] = sort;
        data['count'] = itemcount;
        var data = data;

        jQuery.ajax({
          url: ajax_object.ajax_url,
          type: "post",
          data: data,
          beforeSend: function () {
            loadmore.addClass("active");
          },
          complete: function () {
            loadmore.removeClass("active");
          },
          success: function (response) {
            var posts = JSON.parse(response);
            var countp = jQuery(posts[0]).filter(".single-wander").length;
            console.log(countp);
            if (posts == "" || countp < 1 ) {
              console.log("empty");
              jQuery(".LoadMore").hide();
            }
            jQuery('#loader-icon').addClass("hide");

            if( countp > 0) {
              console.log(posts[0]);
              listDiv.append(posts[0]);
              /**to remove empty hike info*/
              toRemoveEmptyHikeInfo();
              jQuery(".noWanderung").remove();
            }else{
            
              if(jQuery(".noWanderung").length < 1){
                jQuery("#wanderung-loadmore").before(posts);
              }
            }
          },
          error: function () {
            jQuery('#loader-icon').addClass("hide");
          },
        });
      }
    
    });

    // cookie set for checking checkbox
    jQuery(document).on("change", " .sort_dropdown label input[type=checkbox]", function () {

        var sort_type = jQuery(this).prop("name");
        var sort = '';

        if(jQuery(this).prop('checked') == true){

          if( sort_type == 'sort_large' ){ 
              var sort = "large";
              if(window.innerWidth < 1200){
                  if(jQuery(".ListHead.mob .sort-shortest").prop('checked') == true ){
                      jQuery(".ListHead.mob .sort-shortest").prop('checked', false ); 

                  }
              }else{
                  if(jQuery(".ListHead .sort-shortest").prop('checked') == true ){
                      jQuery(".ListHead .sort-shortest").prop('checked', false ); 

                  }
              }
          }else if( sort_type == 'sort_short' ){
            var sort = "short";
              if(window.innerWidth < 1200){
                  if( jQuery(".ListHead.mob .sort-largest").prop('checked') == true ){
                      jQuery(".ListHead.mob .sort-largest").prop('checked', false ); 
                  }
              }else{
                  if( jQuery(".ListHead .sort-largest").prop('checked') == true ){
                      jQuery(".ListHead .sort-largest").prop('checked', false ); 
                  }
              }

          }
        }else if(jQuery(this).prop('checked') == false){

        }
        var data = generate_data_array(null);

        var mapDragEvent = $('#wanderung-loadmore').data("event");
        data['filtered_map_ids'] = $('#mapDragFilterHikeId').val();

        // if (mapDragEvent == 'dragMap') {
          data['action'] = "wanderung_drag_map_hikes_sort_query";
        // } else {
        //   data['action'] = "get_wanderung_sort_query";
        // }
        data['nonce'] = ajax_object.ajax_nonce;
        data['sort'] = sort;

        jQuery.ajax({
          url: ajax_object.ajax_url,
          type: "post",
          data: data,
          beforeSend: function () {
            loadmore.show();
            jQuery("#wegw-preloader").css("display","block");
          },
          success: function (response) {
            var posts = JSON.parse(response);
            var countp = jQuery(posts[0]).filter(".single-wander").length;
            console.log(countp);
            if (posts == "" || countp < 1 ) {
              console.log("empty");
              jQuery(".LoadMore").hide();
            }
            if( countp > 0) {
              jQuery(".single-wander-wrappe").html(posts);
            }
             /**to remove empty hike info*/
            toRemoveEmptyHikeInfo();
            jQuery("#wegw-preloader").css("display","none");
          },
          error: function () {},
        });
        
      });

    // header search
      jQuery('.header_menu .search_head').keyup(function(e) { 
        if (e.key === 'Enter' || e.keyCode === 13) {
        
          /* Remove `dragMap` from load more btn */
          $('#wanderung-loadmore').attr("data-event", "");
      
          var data = generate_data_array(null);

          data['action'] = "get_wanderung_sort_query";
          data['nonce'] = ajax_object.ajax_nonce;
          jQuery.ajax({
            url: ajax_object.ajax_url,
            type: "post",
            data: data,
            beforeSend: function () {
              loadmore.show();
              jQuery("#wegw-preloader").css("display","block");
            },
            success: function (response) {
              var posts = JSON.parse(response);
              var countp = jQuery(posts[0]).filter(".single-wander").length;
              console.log(countp);
              if (posts == "" || countp < 1 ) {
                jQuery(".LoadMore").hide();
              }
              if( countp > 0) {
                jQuery(".single-wander-wrappe").html(posts);
                jQuery(".noWanderung").remove();
              }else{
                jQuery(".single-wander-wrappe").html('');
                if(jQuery(".noWanderung").length < 1){
                  jQuery("#wanderung-loadmore").before('<h2 class="noWanderung">'+ posts[1] + '</h2>');
                }
              }
              jQuery("#wegw-preloader").css("display","none");
              jQuery('#searchbox_main_filter').val(jQuery('.header_menu .search_head').val());
            },
            error: function () {},
          });
        // wegw_map_filter_results('hover', e);
          wegw_map_filter_results('btnClick', e);
        }
      });
    /*
    * Filter hike results via main sidebar
    */
    jQuery('#wegw_map_filter_btn').on("click",function (e) {
          /* Remove `dragMap` from load more btn */
          $('#wanderung-loadmore').attr("data-event", "");
          $('#mapDragFilterHikeId').remove();
          wegw_map_filter_results('btnClick', e);
          jQuery("#wegw-preloader").css("display","block");
          jQuery('.filterMenu').addClass('filterWindow');
    });

    jQuery('.filter_reset').on("click",function (e) {
      /* Remove `dragMap` from load more btn */
      $('#wanderung-loadmore').attr("data-event", "");
      $('#mapDragFilterHikeId').remove();
      reset_filter('btnClick', e);

    });
  
    /* clear the menu serach when clicked on close icon  */
    jQuery('.navigation_search .navigation_search_close').on("click",function (e) {
      jQuery(".navigation_search input").val("");
      jQuery('.navigation_search_close').addClass("hide");
    });
    /* clear the serach on responsive map when clicked on close icon  */
    jQuery('#map-resp .map_main_search  .map_main_search_close').on("click",function (e) {
      jQuery("#map-resp .map_main_search  input").val("");
      jQuery('#map-resp .map_main_search_close').addClass("hide");
    });
    /* clear the serach on desktop map when clicked on close icon  */
    jQuery('#map_desktop .map_main_search  .map_main_search_close').on("click",function (e) {
      jQuery("#map_desktop .map_main_search  input").val("");
      jQuery('#map_desktop .map_main_search_close').addClass("hide");
    });
    /* clear the serach in header when clicked on close icon  */
    jQuery('.head_navigation_search .head_navigation_search_close').on("click",function (e) {
      jQuery(".head_navigation_search input").val("");
      jQuery('.head_navigation_search_close').addClass("hide");
    });

});
    
function wegw_map_filter_results(eventType, e) {
     
    /* Sort Order */

    /* Searchbox Filter */
    var data = generate_data_array(null);
    data['action'] = "get_wanderung_sidebar_filter_query";
    data['event_type'] = eventType;
    data['event'] = "total_hikes_filter";
    data['nonce'] = ajax_object.ajax_nonce;
    $.ajax({
      url: ajax_object.ajax_url,
      type: "POST",
      data: data,
      beforeSend: function () {
        if(eventType == "hover"){
          jQuery('#loader-icon-filter').removeClass("hide");
          jQuery('.wegw_filtered_result_count').addClass("hide");
        }else{
          jQuery("#wegw-preloader").css("display","block");
        }
      },
      success: function (response) { 
        if( eventType == "hover" ) {
          $('.wegw_filtered_result_count').html(response);
          jQuery('.header_menu .search_head').val(jQuery('#searchbox_main_filter').val());
          jQuery('#loader-icon-filter').addClass("hide");
          jQuery('.wegw_filtered_result_count').removeClass("hide");
        } else if(eventType == "btnClick") {

          /* Check if the `Click` event is triggered or actually clicked */
          if( e.which ) {
            var posts = JSON.parse(response);
            var countp = jQuery(posts[0]).filter(".single-wander").length;
            
            if (posts == "" || countp < 1) {
              jQuery(".LoadMore").hide();
            } else {
              jQuery(".LoadMore").show();
            }

            /* 
              * Update respose coming from ajax function inside html
              * If hike count = 0. In script `places` load as empty json
              * Else load complete hike html inside the script
              */
            jQuery(".single-wander-wrappe").html(posts[0]);

            if( countp > 0) {
              $('.wegw_filtered_result_count').html(posts.count);
              jQuery(".noWanderung").remove();
            } else {
              jQuery(".single-wander-wrappe").html('');
              if(jQuery(".noWanderung").length < 1){
                jQuery("#wanderung-loadmore").before('<h2 class="noWanderung">'+ posts[1] + '</h2>');
              }
            }
            /* If `Click` event is actually clicked trigger automatically to plot cluster markers */
            $("#wegw_map_filter_btn").trigger("click");
          }
           /**to remove empty hike info*/
          toRemoveEmptyHikeInfo();
          jQuery("#wegw-preloader").css("display","none");
        } 
      },
      error: function () {},
    });

  }

  /** header search clear  */
function clearSearch() {
    jQuery(".header_menu .search.search input").val("");
    jQuery('.header_menu .filter_search_close').addClass("hide");
    jQuery('#searchbox_main_filter').val("");
    //  document.cookie = 'wegw_loc' +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    location.reload();
}

  /* Reset filter option values */
  function reset_filter(eventType, e) {
   
    /* Reset search place textbox value & remove location cookie */
    clearSearchFilter();
  
    /* Reset slider `Umgebungssuche` */
    $('#radius_search').val( '0km' );
  
    /* Reset `Schwierigkeitsgrad` values */
    $('.fc_diff_level label').removeClass('active');
  
    /* Reset `Nach Monaten` values */
    $('.fc_block_month label').removeClass('active');
  
    /* Reset multi sliders */
    resetSlider();

    clearActivityCheck();
  
    $('.activity_search').prop('checked', false);
    $('.difficulty_search').prop('checked', false);
    $('.wanderregionen_search').prop('checked', false);
    $('.angebote_search').prop('checked', false);
    $('.thema_search').prop('checked', false);
    $('.routenverlauf_search').prop('checked', false);
    $('.ausdauer_search').prop('checked', false);
    jQuery('.filterMenu .filter_content_wrapper input[type=checkbox]').prop('checked', false);

    var data = generate_data_array('reset');

      data['action'] = "get_wanderung_sidebar_filter_query";
      data['event_type'] = eventType;
      data['event'] = "total_hikes_filter";
      data['nonce'] = ajax_object.ajax_nonce;
    $.ajax({
        url: ajax_object.ajax_url,
        type: "POST",
        data: data,
        beforeSend: function () {
          if(eventType == 'hover'){
              jQuery('#loader-icon-filter').removeClass("hide");
                jQuery('.wegw_filtered_result_count').addClass("hide");
          }else{
              jQuery("#wegw-preloader").css("display","block");
          }
         
        },
        success: function (response) {
          if(eventType == 'hover'){
              jQuery('.wegw_filtered_result_count').html(response);
              jQuery('#loader-icon-filter').addClass("hide");
              jQuery('.wegw_filtered_result_count').removeClass("hide");
          }else if(eventType == 'btnClick'){
              if( e.which ) {
                var posts = JSON.parse(response);
                var countp = jQuery(posts[0]).filter(".single-wander").length;
                if (posts == "" || countp < 1) {
                  console.log("empty");
                  jQuery(".LoadMore").hide();
                } else {
                  jQuery(".LoadMore").show();
                }

                /* 
                * Update respose coming from ajax function inside html
                * If hike count = 0. In script `places` load as empty json
                * Else load complete hike html inside the script
                */
                jQuery(".single-wander-wrappe").html(posts[0]);

                if( countp > 0) {
                  $('.wegw_filtered_result_count').html(posts.count);
                  jQuery(".noWanderung").remove();
                } else {
                  jQuery(".single-wander-wrappe").html('');
                  if(jQuery(".noWanderung").length < 1){
                    jQuery("#wanderung-loadmore").before('<h2 class="noWanderung">'+ posts[1] + '</h2>');
                  }
                }
                $(".filter_reset").trigger("click");

              }
               /**to remove empty hike info*/
              toRemoveEmptyHikeInfo();
              jQuery("#wegw-preloader").css("display","none");
          }
        },
        error: function () {},
      });
  }

/* Function to reset multi sliders value */
function resetSlider() {

  jQuery(".slider.multi-slide").each(function(i, data) {
    // $this is a reference to .slider in current iteration of each
    var $this = jQuery(this);
    // find any .slider-range element WITHIN scope of $this
    jQuery(".slider-range", $this).slider({
        range: true,
        min: parseInt($this.attr('data-initial')),
        max: parseInt($this.attr('data-final')),
         values: [parseInt($this.attr('data-initial')), parseInt($this.attr('data-final'))],
    });
    if($this.attr('data-notation') === 'h'){
        if($this.attr('data-first') <= 9){
            jQuery(".firstVal", $this).val("0"+$this.attr('data-initial')+':00 ' + $this.attr('data-notation'));
            jQuery($this).attr("data-first", $this.attr('data-initial'));
        }else{
            jQuery(".firstVal", $this).val($this.attr('data-initial')+':00 ' + $this.attr('data-notation'));
            jQuery($this).attr("data-first", $this.attr('data-initial'));
        }
        if($this.attr('data-second') <= 9){
            jQuery(".secondVal", $this).val('> 0'+$this.attr('data-final')+':00 ' + $this.attr('data-notation'));
            jQuery($this).attr("data-second", $this.attr('data-final'));
        }else{
            jQuery(".secondVal", $this).val('> '+$this.attr('data-final')+':00 ' + $this.attr('data-notation'));
            jQuery($this).attr("data-second", $this.attr('data-final'));
        }
        
    }else{
      jQuery(".firstVal", $this).val($this.attr('data-initial') + " "+$this.attr('data-notation'));
      jQuery(".secondVal", $this).val($this.attr('data-final') +" "+ $this.attr('data-notation'));
      jQuery($this).attr("data-first", $this.attr('data-initial'));
      jQuery($this).attr("data-second", $this.attr('data-final'));
    }

  });

}

function generate_data_array(dataReset) {
  var initial, final;
  //get initial and final data of double slider in filter window
  if(dataReset === 'reset'){
    initial = 'data-initial';
    final = 'data-final';
  }else{
    initial = 'data-first';
    final = 'data-second';
  }

  var loc = jQuery('.header_menu .search_head').val();
  var itemcount = jQuery(".single-wander").length;
  var sort = '';
  //get the sort large/short
  if(window.innerWidth < 1200){
    if( jQuery(".ListHead.mob .sort-largest").prop('checked') == true ){
          var sort = 'large'; 
    }
    if( jQuery(".ListHead.mob .sort-shortest").prop('checked') == true ){
          var sort = 'short'; 
    }
  }else{
    if( jQuery(".ListHead .sort-largest").prop('checked') == true ){
          var sort = 'large'; 
    }
    if( jQuery(".ListHead .sort-shortest").prop('checked') == true ){
          var sort = 'short'; 
    }
  }

  // var searchbox_filter = $('#searchbox_main_filter').val();
  var searchbox_filter = "";

  /* Umgebungssuche - Radius Search */
  // var radius_search = $('#radius_search').val().replace(/\D/g,'');
  var radius_search = "";

  jQuery('.singleVal').css('left','0');
  /* Activity */
  var activity_search = [];
  $('.activity_search:checked').each(function(){
      activity_search.push($(this).val());
  });

  /* Schwierigkeitsgrad - Difficulty level */
  var difficulty_search = [];
  // $('.difficulty_search:checked').each(function(){
  //     difficulty_search.push($(this).val());
  // });
  var valuesArray;
  $('.difficulty_search:checked').each(function(){
    var activeParentCheckboxes = $('.difficulty_search').filter(function() {
      return $(this).parent().hasClass('active');
    });
    
     valuesArray = activeParentCheckboxes.map(function() {
      return $(this).val();
    }).get();
  });
  difficulty_search = difficulty_search.concat(valuesArray);
  /** if Winterwandern is selected */
  if(activity_search.includes('19')){
    difficulty_search = [];
  }

  /* Dauer - Hiking Duration */
  var duration_start_point = $('.dauer-slider').attr(initial);
  var duration_end_point = $('.dauer-slider').attr(final);

  /* Kilometer */
  var distance_start_point = $('.km-slider').attr(initial);
  var distance_end_point = $('.km-slider').attr(final);
  /* Ascent */
  var ascent_start_point = $('.aufstieg-slider').attr(initial);
  var ascent_end_point = $('.aufstieg-slider').attr(final);

  /* Descent */
  var descent_start_point = $('.abstieg-slider').attr(initial);
  var descent_end_point = $('.abstieg-slider').attr(final);

  /* Wanderregion */
  var wanderregionen_search = [];
  $('.wanderregionen_search:checked').each(function(){
      wanderregionen_search.push($(this).val());
  });

  /* Angebote */
  var angebote_search = [];
  $('.angebote_search:checked').each(function(){
      angebote_search.push($(this).val());
  });

  /* Thema */
  var thema_search = [];
  $('.thema_search:checked').each(function(){
      thema_search.push($(this).val());
  });

  /* Routenverlauf */
  var routenverlauf_search = [];
  $('.routenverlauf_search:checked').each(function(){
      routenverlauf_search.push($(this).val());
  });

  /* Ausdauer */
  var ausdauer_search = [];
  $('.ausdauer_search:checked').each(function(){
      ausdauer_search.push($(this).val());
  });

  /* Tiefster / höchster Punkt */
  // var altitude_start_point = $('#altitude_start_point').val().replace(/\D/g,'');
  // var altitude_end_point = $('#altitude_end_point').val().replace(/\D/g,'');
  var altitude_start_point = $('.aaltitude-slider').attr(initial);
  var altitude_end_point = $('.aaltitude-slider').attr(final);

  /* Nach Monaten */
  var wander_saison_search = [];
  $('.wander_saison_search:checked').each(function(){
      wander_saison_search.push($(this).val());
  });

  var data = {
    loc: loc,
    sort:sort,
    itemcount:itemcount,
    'searchbox_filter': searchbox_filter,
    'radius_search': radius_search,
    'activity_search': activity_search,
    'difficulty_search': difficulty_search,
    'duration_start_point': duration_start_point,
    'duration_end_point': duration_end_point,
    'distance_start_point': distance_start_point,
    'distance_end_point': distance_end_point,
    'ascent_start_point': ascent_start_point,
    'ascent_end_point': ascent_end_point,
    'descent_start_point': descent_start_point,
    'descent_end_point': descent_end_point,
    'wanderregionen_search': wanderregionen_search,
    'angebote_search': angebote_search,
    'thema_search': thema_search,
    'routenverlauf_search': routenverlauf_search,
    'ausdauer_search': ausdauer_search,
    'altitude_start_point': altitude_start_point,
    'altitude_end_point': altitude_end_point,
    'wander_saison_search': wander_saison_search,
  };
  return data;
}

         