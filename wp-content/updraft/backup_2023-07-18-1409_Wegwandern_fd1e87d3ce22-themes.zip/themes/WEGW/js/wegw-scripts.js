jQuery(document).ready(function($) {

	/*
	 * Show current location onclick
	
    $(document).on("click", "#current_location_icon", function() {
        // if (navigator.geolocation) {
        //     navigator.geolocation.getCurrentPosition(showLocation);
        // } else {
        //     $('#current_location_container').html('Geolocation is not supported by this browser.');
        // }

        var geolocation = new ol.Geolocation({
            projection: map.getView().getProjection(),
            tracking: true,
            trackingOptions: {
                enableHighAccuracy: true
            }
        });

        console.log(geolocation);

    }); */

    /* Commented as geolocation update made via openlayers
    function showLocation(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: {
			    action : 'wegwandern_current_location',
			    latitude : latitude,
			    longitude: longitude
			},
            success: function(msg) {
                if (msg) {
                    $("#current_location_container").html(msg);
                } else {
                    $("#current_location_container").html('Not Available');
                }
            }
        });
    } */

    /*
     * Get hike GPX file data
     */
  /*  $(document).on("click", ".single-wander-map", function() {
        var hikeID = $(this).attr("data-hikeid");

        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: {
                action : 'wegwandern_get_hike_gpx_file',
                hike_id: hikeID
            },
            success: function(resp) {
                if (resp) {
                    console.log(JSON.parse(resp));
                } else {
                    console.log("Response error!");
                }
            }
        });
    });*/

});