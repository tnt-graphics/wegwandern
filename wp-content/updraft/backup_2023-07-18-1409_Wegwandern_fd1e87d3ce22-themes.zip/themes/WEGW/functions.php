<?php
/**
 * Wegwandern functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Wegwandern
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.3' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function wegwandern_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on Wegwandern, use a find and replace
		* to change 'wegwandern' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'wegwandern', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'wegwandern' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'wegwandern_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'wegwandern_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function wegwandern_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'wegwandern_content_width', 640 );
}
add_action( 'after_setup_theme', 'wegwandern_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function wegwandern_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'wegwandern' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'wegwandern' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'wegwandern_widgets_init' );

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/general-settings.php';

/**
 * Functions for backend map integration into WordPress.
 */
require get_template_directory() . '/inc/admin-map-widget.php';

/**
 * Functions which enhance the theme by options into WordPress.
 */
require get_template_directory() . '/inc/theme-options.php';

/**
 * Enqueue scripts.
 */
require get_template_directory() . '/inc/wp-scripts.php';

/**
 * Custom widgets initialization.
 */
require get_template_directory() . '/inc/wp-widgets.php';

/**
 * Breadcrumbs initialization.
 */
require get_template_directory() . '/inc/breadcrumb.php';

/**
 * Ajax functions initialization.
 */
require get_template_directory() . '/inc/ajax-functions.php';

/**
 * Gutenberg block initialization.
 */
require get_template_directory() . '/inc/acf-block-elements.php';

/**
 * Gutenberg block patterns initialization.
 */
require get_template_directory() . '/inc/block-patterns.php';
/**
 * Wanderung filter section.
 */

require get_template_directory() . '/inc/wegw-filter.php';

/**
 * Wanderung planen section.
 */
require get_template_directory() . '/inc/wanderung-planen.php';

/**
 * Wanderung region slider.
 */
require get_template_directory() . '/inc/wanderung-region-slider.php';

add_filter(
	'wp_check_filetype_and_ext',
	function( $data, $file, $filename, $mimes ) {

		global $wp_version;
		if ( $wp_version !== '4.7.1' ) {
			return $data;
		}

		$filetype = wp_check_filetype( $filename, $mimes );

		return array(
			'ext'             => $filetype['ext'],
			'type'            => $filetype['type'],
			'proper_filename' => $data['proper_filename'],
		);

	},
	10,
	4
);
/**
 * Function to add svg support.
 */
function wegw_cc_mime_types( $mimes ) {
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}
  add_filter( 'upload_mimes', 'wegw_cc_mime_types' );

function wegw_fix_svg() {
	echo '<style type="text/css">
		  .attachment-266x266, .thumbnail img {
			   width: 100% !important;
			   height: auto !important;
		  }
		  </style>';
}
  add_action( 'admin_head', 'wegw_fix_svg' );

/*
 * Print data in specified format - for developer convenience
 */
function pre( $data ) {
	echo '<pre>';
	print_r( $data );
	echo '</pre>';
}

/*
 * Ajax function for getting current location
 */
add_action( 'wp_ajax_wegwandern_current_location', 'wegwandern_current_location' );
add_action( 'wp_ajax_nopriv_wegwandern_current_location', 'wegwandern_current_location' );

function wegwandern_current_location() {
	if ( ! empty( $_POST['latitude'] ) && ! empty( $_POST['longitude'] ) ) {
		$url    = 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim( $_POST['latitude'] ) . ',' . trim( $_POST['longitude'] ) . '&key=YOUR_API_KEY';
		$json   = @file_get_contents( $url );
		$data   = json_decode( $json );
		$status = $data->status;

		if ( $status == 'OK' ) {
			$location = $data->results[0]->formatted_address;
		} else {
			$location = '';
		}

		/* return address to ajax */
		echo $location;
	}

	die();
}

/*
 * Ajax function for getting hike GPX file
 */
add_action( 'wp_ajax_wegwandern_get_hike_gpx_file', 'wegwandern_get_hike_gpx_file' );
add_action( 'wp_ajax_nopriv_wegwandern_get_hike_gpx_file', 'wegwandern_get_hike_gpx_file' );

function wegwandern_get_hike_gpx_file() {
	if ( ! empty( $_POST['hike_id'] ) && ! empty( $_POST['hike_id'] ) ) {
		$gpx_file_name = get_field_object( 'gpx_file', $_POST['hike_id'] );
		$gpx_file      = get_field( 'gpx_file', $_POST['hike_id'] );
		$json_gpx_data = get_field( 'json_gpx_file_data', $_POST['hike_id'] );

		$arr = array(
			'gpx_file_name' => $gpx_file_name['value'],
			'json_gpx_data' => $json_gpx_data,
		);
		echo json_encode( $arr );
	}
	die();
}

add_filter( 'body_class', 'custom_body_class' );
/**
 * Add custom field body class(es) to the body classes.
 *
 * It accepts values from a per-page custom field, and only outputs when viewing a singular static Page.
 *
 * @param array $classes Existing body classes.
 * @return array Amended body classes.
 */
function custom_body_class( array $classes ) {
	global $post;
	$head_class = get_field( 'head_class', $post->ID );
	$body_cls   = ( $head_class ) ? 'transHead' : '';
	$new_class  = is_singular( 'wanderung' ) ? 'TopAd' : '';

	if ( $new_class ) {
		$classes[] = $new_class;
	}
	if ( $body_cls ) {
		$classes[] = $body_cls;
	}
	if ( is_search() ) {
		$remove_classes = array( 'search' );
		$classes        = array_diff( $classes, $remove_classes );
	}
	return $classes;
}
add_filter( 'nav_menu_css_class', 'special_nav_class', 10, 2 );

function special_nav_class( $classes, $item ) {
	if ( in_array( 'current-menu-item', $classes ) ) {
		$classes[] = 'active ';
	}
	return $classes;
}

add_action(
	'load-post.php',
	function() {
		add_filter( 'wp_terms_checklist_args', 'wpse_terms_checklist_args' );
	}
);

function wpse_terms_checklist_args( $args ) {
	// Target the 'schedule' custom post type edit screen
	if ( 'wanderung' === get_current_screen()->id ) {
		add_filter( 'get_terms_args', 'wpse_terms_args', 10, 2 );
	}
	return $args;
}

function wpse_terms_args( $args, $taxonomies ) {
	// Target the 'all' tab in the 'schedule_day_taxonomy' terms check list
	if (
		   isset( $args['get'] )
		&& 'all' === $args['get']
		&& isset( $taxonomies[0] )
		&& 'wander-saison' === $taxonomies[0]
	) {
		// Modify the term order
		$args['orderby'] = 'ID';  // <-- Adjust this to your needs!
		$args['order']   = 'ASC'; // <-- Adjust this to your needs!

		// House cleaning - Remove the filter callbacks
		remove_filter( current_filter(), __FUNCTION__ );
		remove_filter( 'wp_terms_checklist_args', 'wpse_terms_checklist_args' );
	}
	return $args;
}
