<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Wegwandern
 */
get_header();
global $post;

$wanderung_id        = $post->ID;
$wanderregionen      = get_the_terms( $wanderung_id, 'wanderregionen' );
$wanderregionen_name = ( ! empty( $wanderregionen ) ) ? $wanderregionen[0]->name : 'Region';
$hike_level          = get_the_terms( $wanderung_id, 'anforderung' );
$hike_level_name     = ( ! empty( $hike_level ) ) ? $hike_level[0]->name : '';
$hike_level_cls      = wegw_wandern_hike_level_class_name( $hike_level_name, $wanderung_id );

$hike_time     = ( get_field( 'dauer', $wanderung_id ) ) ? get_field( 'dauer', $wanderung_id ) : '';
$hike_distance = ( get_field( 'km', $wanderung_id ) ) ? get_field( 'km', $wanderung_id ) : '';
$hike_ascent   = ( get_field( 'aufstieg', $wanderung_id ) ) ? get_field( 'aufstieg', $wanderung_id ) : '';
$hike_descent  = ( get_field( 'abstieg', $wanderung_id ) ) ? get_field( 'abstieg', $wanderung_id ) : '';
$kurzbeschrieb = ( get_field( 'kurzbeschrieb', $wanderung_id ) ) ? get_field( 'kurzbeschrieb', $wanderung_id ) : 'Fuga Nequam nos dolupta testinu llaceri ssequi nihilit, ut quissedia voluptassint prenimusam inum harchit imet am, aped mos volorio nsequos qui sundendestis aped mos volorio inum Onsequos et ...';

$wander_saison_name = wegw_wandern_saison_name( $wanderung_id );
$gpx_file           = ( get_field( 'gpx_file', $wanderung_id ) ) ? get_field( 'gpx_file', $wanderung_id ) : 'undefined';

/* Check if have gpx file in field */
if ( $gpx_file != 'undefined' ) {
	$json_gpx_data = get_field( 'json_gpx_file_data', $wanderung_id );
} else {
	$json_gpx_data = 'undefined';
}

if ( have_rows( 'manage_ad_scripts', 'option' ) ) :
	while ( have_rows( 'manage_ad_scripts', 'option' ) ) :
		the_row();

		$desktop_ad_scripts        = get_sub_field( 'desktop_ad_scripts', 'option' );
		$ad_script_desktop_300x600 = '';
		$ad_script_desktop_994x500 = '';

		foreach ( $desktop_ad_scripts as $desktop_ad ) {
			if ( $desktop_ad['ad_size'] == '300×600' ) {
				$ad_script_desktop_300x600 = $desktop_ad['ad_script'];
			}
			if ( $desktop_ad['ad_size'] == '994x500' ) {
				$ad_script_desktop_994x500 = $desktop_ad['ad_script'];
			}
		}

		$tablet_ad_scripts        = get_sub_field( 'tablet_ad_scripts', 'option' );
		$ad_script_tablet_300×250 = '';
		$ad_script_tablet_300×600 = '';

		foreach ( $tablet_ad_scripts as $tablet_ad ) {
			if ( $tablet_ad['ad_size'] == '300×250' ) {
				$ad_script_tablet = $tablet_ad['ad_script'];
			}
			if ( $tablet_ad['ad_size'] == '300×600' ) {
				$ad_script_tablet_300×600 = $tablet_ad['ad_script'];
			}
		}

		$mobile_ad_scripts = get_sub_field( 'mobile_ad_scripts', 'option' );
		$ad_script_mobile  = '';
		foreach ( $mobile_ad_scripts as $mob_ad ) {
			if ( $mob_ad['ad_size'] == '300×250' ) {
				$ad_script_mobile = $mob_ad['ad_script'];
			}
		}

   endwhile;
endif;
wanderung_planen_section();
?>

<main id="primary" class="single-detail-wander">
<?php
	$header_slider = get_field( 'header_slider', $post->ID );


	$post_thumb    = get_the_post_thumbnail_url( $post->ID, 'full' );
	$thumb         = get_the_post_thumbnail_url( $post->ID, 'thumbnail' );
	$thumb_caption = get_the_post_thumbnail_caption( $post->ID );
	$count_html    = '';
if ( ! empty( $post_thumb ) ) {
	if ( ! empty( $header_slider ) ) {
		 $count_slide = count( $header_slider );
		 $count_slide = $count_slide + 1;
		 //$count_html  = '<div id="counter">' . $count_slide . '</div>';
		 $count_html = '<div id="counter" onclick="openLightGallery(this)">1/' . $count_slide . '</div>';
	}else{
		$count_html = '<div id="counter" onclick="openLightGallery(this)">1/1</div>';
	}
	?>



<div class="container-fluid">
	<div class="demo-gallery">
		<?php echo $count_html; ?>
		<div id="lightgallery" class="single-wander-img list-unstyled row">
		 <div class="justified-gallery" data-src="<?php echo $post_thumb; ?>" data-sub-html="<?php echo $thumb_caption; ?>">
				<a href="<?php echo $post_thumb; ?>">
					<img class="wander-img detail-wander-img" src="<?php echo $post_thumb; ?>" />
					<div class="single-wander-heart detail-single-wander-heart"></div>
				</a>
			</div>
		   <?php
			if ( ! empty( $header_slider ) ) {
				foreach ( $header_slider as $slide ) {
					?>
				  <div class="justified-gallery"
				  data-src="<?php echo $slide['image']['url']; ?>" data-thumb="<?php echo $slide['image']['sizes']['thumbnail']; ?>"
					data-sub-html="<?php echo $slide['image']['caption']; ?>">
					<a href="<?php echo $slide['image']['url']; ?>">
					  <img class="wander-img detail-wander-img" src="<?php echo $slide['image']['sizes']['thumbnail']; ?>" />
					</a>
				  </div>
						<?php
				}
			}
			?>
				</div>
			  </div>
</div>


<?php } ?>

<div class="container">
	<h6 class='detail-region'><?php echo $wanderregionen_name; ?></h6>
	<h1 class='detail-title'><?php echo get_the_title( $wanderung_id ); ?></h1>
	<div class='detail-wrapper'>
<div class="single-hike-left">
   <h6 class='detail-region-resp'><?php echo $wanderregionen_name; ?></h6>
   <h2 class='detail-title-resp'><?php echo get_the_title( $wanderung_id ); ?></h2>
	
<div class="detail-infobox">
   <div class="detail-hike-details" >

	  <?php if ( isset( $hike_level_cls ) && $hike_level_cls != '' ) { ?>
		 <div class="hike_level">
			   <span class="<?php echo $hike_level_cls; ?>"></span>
			   <p><?php echo $hike_level_name; ?></p>
		 </div>
	  <?php } ?>

	  <?php if ( isset( $hike_time ) && $hike_time != '' ) { ?>
		 <div class="hike_time">
			<span class="hike-time-icon"></span>
			<p><?php echo $hike_time; ?> h</p>
		 </div>
	  <?php } ?>

	  <?php if ( isset( $hike_distance ) && $hike_distance != '' ) { ?>
		 <div class="hike_distance">
			<span class="hike-distance-icon"></span>
			<p><?php echo round( $hike_distance, 1 ); ?> km</p>
		 </div>
	  <?php } ?>

	  <?php if ( isset( $hike_ascent ) && $hike_ascent != '' ) { ?>
		 <div class="hike_ascent">
			<span class="hike-ascent-icon"></span>
			<p><?php echo $hike_ascent; ?> m</p>
		 </div>
	  <?php } ?>

	  <?php if ( isset( $hike_descent ) && $hike_descent != '' ) { ?>
		 <div class="hike_descent">
			<span class="hike-descent-icon"></span>
			<p><?php echo $hike_descent; ?> m</p>
		 </div>
	  <?php } ?>

	  <?php if ( isset( $wander_saison_name ) & $wander_saison_name != '' ) { ?>
		 <div class="hike_month">
			   <span class="hike-month-icon"></span>
			   <p><?php echo $wander_saison_name; ?></p>
		 </div>
	  <?php } ?>
   </div>
</div>

<?php if ( isset( $kurzbeschrieb ) & $kurzbeschrieb != '' ) { ?>
   <h2 class="wegw-single-page-desc">
	  <?php echo $kurzbeschrieb; ?>
</h2>
<?php } ?>

<div class="wanderung-plan" onclick="openWanderungPlan()">
	<span class="planIcon"></span>
	<span class="planText">Wanderung planen</span>
</div>

<!-- section -->
<div id="weg-map-popup-full-detail-page" >
   <div id="weg-map-popup-inner-wrapper-full-detail-page">
	  <div class="close_map" onclick="closeElementDetailPage(this)"><span class="close_map_icon"></span></div>
	  <div id="cesiumContainer" class="cesiumContainer"></div>
	  <div id="threeD" class="map_3d"></div>
	  <div id="map_direction" class="map_direction"></div>
	  <div class="botom_layer_icon">
		 <div class="accordion" >
			<div class="weg-layer-wrap layer_head">
			   <div class="weg-layer-text">Hintergrund</div>
			</div>
		 </div>
		 <div class="panel">
			<div class="weg-layer-wrap activeLayer" id="colormap_view_section">
			   <div class="weg-layer-text">Karte farbig</div>
			</div>
			<div class="weg-layer-wrap" id="aerial_view_section">
			   <div class="weg-layer-text">Luftbild</div>
			</div>
			<div class="weg-layer-wrap" id="grey_view_section">
			   <div class="weg-layer-text">Karte SW</div>
			</div>
		 </div>
	  </div>
	  <div class="copyRight">
		 <a target="_blank" href="https://www.swisstopo.admin.ch/de/home.html">© swisstopo</a>
	  </div>
	  <div class="map_filter">
		 <div class="map_filter_inner_wrapper">
			<div class="accordion"><?php echo __( 'Karteninformationen', 'wegwandern' ); ?></div>
			<div class="panel">
			   <div class="fc_check_wrap">
				  <label class="check_wrapper"><?php echo __( 'ÖV-Haltestellen', 'wegwandern' ); ?><input type="checkbox" name="" id="transport_layer_checkbox" value=""><span class="redmark"></span></label>
				  <label class="check_wrapper"><?php echo __( 'Gesperrte Wanderwege', 'wegwandern' ); ?>
				  <input type="checkbox" name="" id="closure_hikes_layer" value=""><span class="redmark"></span></label>
				  <label class="check_wrapper"><?php echo __( 'Hangneigungen über 30°', 'wegwandern' ); ?><input type="checkbox" id="slope_30_layer" name="" value=""><span class="redmark"></span></label>
				  <label class="check_wrapper"><?php echo __( 'Wildruhezonen', 'wegwandern' ); ?><input type="checkbox" id="wildlife_layer" name="" value=""><span class="redmark"></span></label>
				  <label class="check_wrapper"><?php echo __( 'Wegpunkte Wegwandern', 'wegwandern' ); ?><input type="checkbox" id="waypoints_layer" name="" value=""><span class="redmark"></span></label>
			   </div>
			</div>
		 </div>
	  </div>
   </div>
	
			   
   <div class="options" id="mapOptions"></div>
	
				  
   <div id="info"></div>
   <div class="popover" id="transport-layer-info-popup">
	  <div class="arrow"></div>
	  <div class="popover-title">
		 <div class="popup-title"><?php echo __( 'Object information', 'wegwandern' ); ?></div>
		 <div class="popup-buttons">
			<!-- <button class="fa-print" title="Print"></button> -->
			<!-- <button class="fa-minus" title="Minimize"></button> -->
			<button class="fa fa-remove" title="Close" onclick="closeTransportLayerPopup()"></button>
		 </div>
	  </div>
	  <div class="popover-content">
		 <div class="popover-scope">
			<div class="popover-binding">
			   <div class="htmlpopup-container" id="tl-content-area"></div>
			</div>
		 </div>
	  </div>
   </div>
	
		   
</div>
<!-- section -->
<!-- map section -->

<div id="weg-map-popup-detail-page-wrapper">
   <div id="cesiumContainer" class="cesiumContainer"></div>
   <div id="threeD" class="map_3d"></div>
   <div id="map_direction" class="map_direction"></div>
   <div class="botom_layer_icon">
	  <div class="accordion">
		 <div class="weg-layer-wrap layer_head">
			<div class="weg-layer-text">Hintergrund</div>
		 </div>
	  </div>
	  <div class="panel">
		 <div class="weg-layer-wrap activeLayer" id="colormap_view_section">
			<div class="weg-layer-text">Karte farbig</div>
		 </div>
		 <div class="weg-layer-wrap" id="aerial_view_section">
			<div class="weg-layer-text">Luftbild</div>
		 </div>
		 <div class="weg-layer-wrap" id="grey_view_section">
			<div class="weg-layer-text">Karte SW</div>
		 </div>
	  </div>
   </div>
   <div class="copyRight">
	  <a target="_blank" href="https://www.swisstopo.admin.ch/de/home.html">© swisstopo</a>
   </div>
   <div class="karte-eleProfile-btn" onclick="openPopupMapDetailPage(this)" data-hikeid="<?php echo $wanderung_id; ?>">
	  <span class="karte-eleProfile-btn-icon"></span>
	  <span class="karte-eleProfile-btn-text">Karte & Höhenprofil</span>
   </div>
</div>

<div id="detailPgPopup"><div id="detailPgPopupContent"></div></div>
<!-- map section -->
			<?php

			while ( have_posts() ) :
				the_post();
					get_template_part( 'template-parts/content', 'page' );

				endwhile; // End of the loop.
			?>
	</div>
	<div class="single-hike-right">
	<div class="ad-section-wrap">
	<p>Anzeige</p>
	




	<div class="ad-section ad-desktop"><?php echo $ad_script_desktop_300x600; ?></div>
	<div class="ad-section ad-tablet"><?php echo $ad_script_tablet_300×250; ?></div>
	<div class="ad-section ad-ipad"><?php echo $ad_script_tablet_300×250; ?></div>
	<div class="ad-section ad-mobile"><?php echo $ad_script_mobile; ?></div>
</div>
			</div>
			
			
	</div>

	<div class="ad-section-wrap full-width">
	<p>Anzeige</p>
	<div class="ad-section ad-desktop"><?php echo $ad_script_desktop_994x500; ?></div>
	<div class="ad-section ad-tablet"><?php echo $ad_script_tablet_300×600; ?></div>
	<div class="ad-section ad-ipad"><?php echo $ad_script_tablet_300×600; ?></div>
	<div class="ad-section ad-mobile"><?php echo $ad_script_mobile; ?></div>
</div>
</div>
<?php wanderung_region_slider(); ?>
</main><!-- #main -->

<script type="text/javascript">
	var json_gpx_data_single_hike_detail = <?php echo $json_gpx_data; ?>; 
	var gpx_file_single_hike_detail = '<?php echo $gpx_file; ?>';
</script>


<?php
get_footer();
