<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Wegwandern
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
	<script type="text/javascript">
var gbucket = gbucket || {}; var setgbpartnertag4406 = true; var setgbpartnertag4407 = true; var setgbpartnertag4408 = true; var setgbpartnertag4409 = true; var setgbpartnertag4410 = true; if(typeof(setgbtargetingobj) == 'undefined') {var setgbtargetingobj = {};} 
</script>
<script type="text/javascript" id="gbconfigscript" src="//gbucket.ch/CH/ch_config_desktop.js"></script>
<script type="text/javascript" id="gbadtag" src="//gbucket.ch/CH/wegwandern/Demo/DE_wegwandern_ROS_Demo_AllFormats.js"></script>
<script type="text/javascript" id="gbadtag" src="//gbucket.ch/CH/wegwandern/Demo/DE_wegwandern_ROS_Demo_AllFormats_Tablet.js"></script>
<script type="text/javascript" id="gbadtag" src="//gbucket.ch/CH/wegwandern/Demo/DE_wegwandern_ROS_Demo_AllFormats_Mobile.js"></script>
<script type="text/javascript" id="gbadtag" src="//gbucket.ch/CH/wegwandern/Demo/DE_wegwandern_ROS_Demo_Outstream_Desktop.js"></script>
<script type="text/javascript" id="gbadtag" src="//gbucket.ch/CH/wegwandern/Demo/DE_wegwandern_ROS_Demo_Outstream_Mobile.js"></script>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<!-- <div id="wegw-preloader" >
	<div id="wegwandern-preloader" ></div>
	<div id="wegw-loader" style="display: none;"></div>
</div> -->
<?php
$idname = '';
global $post;
$show_ad_above_header = get_field( 'show_ad_above_header', $post->ID );
// $menu_img = ( $show_ad_above_header ) ? 'menu_white.svg' :'menu.svg';
if ( is_singular( 'wanderung' ) || $show_ad_above_header ) {
	$idname = 'AdHead';

	if ( have_rows( 'manage_ad_scripts', 'option' ) ) :
		while ( have_rows( 'manage_ad_scripts', 'option' ) ) :
			the_row();
			$ad_script_desktop = get_sub_field( 'ad_script_for_desktop_header', 'option' );
			$ad_script_tablet  = get_sub_field( 'ad_script_for_tab_header', 'option' );
			// $ad_script_ipad        = get_field( 'ad_script_for_ipad', 'option' );
			$ad_script_mobile = get_sub_field( 'ad_script_for_mobile_header', 'option' );
endwhile;
endif;
	?>
<div class='ad-above-header-container'>
	<div class="ad-section ad-desktop"><?php echo $ad_script_desktop; ?></div>
	<div class="ad-section ad-tablet"><?php echo $ad_script_tablet; ?></div>
	<div class="ad-section ad-ipad"><?php echo $ad_script_tablet; ?></div>
	<div class="ad-section ad-mobile"><?php echo $ad_script_mobile; ?></div>
<div class="close_ad" onclick="adCloseHeader()"><span class="close_ad_icon"></span></div>
<div class="ad-scroll-btn">
<div class="ad-scroll-btn-icon"></div><div class="ad-scroll-btn-text" onclick="adScrollToHeader()">Scrolle zu WegWandern.ch</div>
</div>
</div>
	<?php


}
?>
<header id="<?php echo $idname; ?>" >
	<div class="container">
		<div class="header_main_wrapper">
			<div>
			<?php
				$size                   = 'thumbnail';
				$header_logo            = get_field( 'header_logo', 'option' );
				$transparent_logo       = get_field( 'transparent_logo', 'option' );
				$transparent_logo_thumb = $transparent_logo['sizes'][ $size ];
				$transparent_logo_alt   = $transparent_logo['alt'];

				$header_logo_thumb = $header_logo['sizes'][ $size ];
				$header_logo_alt   = $header_logo['alt'];
			?>
			 <div class="logo">
				<a class="" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php if ( ! empty( $header_logo ) ) : ?>
					<img src="<?php echo esc_url( $header_logo_thumb ); ?>" alt="<?php echo esc_attr( $header_logo_alt ); ?>" />
					<?php endif; ?>
					</a>
			</div>
		  </div>
		  <div class="header_menu">
		  <?php
			/*
			?>
			 <div class="search">
				<span class="filter_search-icon">
			   </span>
				<input type="text" placeholder="<?php echo esc_html__( 'Ort, Region', 'wegwandern' ); ?>" name="search" class="search_head">
				<span class="filter_search_close hide" onclick="clearSearch()"></span>
			 </div>
			 <?php */
			?>
			 
			 <div class="head_search">
				<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<h3><?php echo esc_attr_x( 'WegWandern.ch durchsuchen', 'placeholder', 'wegwandern' ); ?></h3>
					<div class="head_navigation_search search">
					<span class="filter_search-icon"></span>
					<input type="text" id="navigation_menu" class="" placeholder="<?php echo esc_attr_x( 'Suche', 'placeholder', 'wegwandern' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />

					<span class="head_navigation_search_close hide"></span>
					</div>
				</form>
			 </div>
			
			 <!-- <div class="neighborhood" id="current_location_icon"><img src="<?php // echo get_template_directory_uri() . '/img/in_der_umgebung.svg'; ?>"></div> -->
			<?php
				  $tourenportal_page = get_field( 'select_tourenportal_page', 'option' );
				  $tourenportal_id   = url_to_postid( $tourenportal_page );
				  global $post;
				  $current_url = $post->ID;
			if ( $current_url == $tourenportal_id ) {

				?>
					<!-- <img src="<?php // echo get_template_directory_uri() . '/img/filter.svg'; ?>"> -->
				 <div class="touren_portal" onclick="openFilter()"></div>
					<?php
			} else {
				?>
			 <a href="<?php echo $tourenportal_page; ?>"><div class="touren_portal"></div></a>
			 <?php } ?>
			 <div class="login"></div>
			 <div class="menu"><img class="menu_grey" src="<?php echo get_template_directory_uri() . '/img/menu.svg'; ?>" onclick="openMainMenu()">
			 </div>
		  </div>
		</div>
	 
	   
   </div>
</header>
<?php
// global $template;
// echo basename($template);
// echo wp_get_attachment_image( 729, 'hike-thumbnail' );
?>
<?php
// dynamic_sidebar( 'filter_widget' );
	echo wegw_filter_html();
?>
<div class="main-menu mainMenuWindow" >
<div class="menu_title">
<a href="<?php echo $tourenportal_page; ?>">
	<div class="touren_portal"></div>
	<h3><?php echo esc_html__( 'Zum Tourenportal', 'wegwandern' ); ?></h3>
</a>
<div class="close_warap"><span class="menu_close" onclick="closeMainMenu()"></span></div>
</div>
<?php
/*
?><div class="menuSearchWrap"><div class="menu_search search">
<span class="filter_search-icon"></span>
<input type="text" id="searchbox_menu" class="" placeholder="Ort, Region" name="search">
<span class="menu_search_close hide"></span>
</div>
</div>
<?php */
?>
<div class="menu_content_wrapper">
<?php
				wp_nav_menu(
					array(
						'menu'            => 'main-menu',
						'container'       => 'ul',
						'container_class' => 'menu',
						'menu_class'      => 'menu',
					)
				);

				 echo do_shortcode( '[formidable id=2]' );
				?>
			<?php get_search_form(); ?>

</div>
</div>
