<?php /* Template Name: B2B Login Template */ 
get_header();
?>

<div class="loginMenu ">
<div class="login_content_wrapper">

<h3>Account erstellen oder einloggen</h3>
<?php /*?>   
<form method="post" action="<?php echo site_url( '/wp-login.php' ); ?>">
<input type="text" class="username" placeholder="E-Mail-Adresse" value="" name="log">
<input type="password" class="password" placeholder="Passwort" value="" name="pwd">
<label class="check_wrapper">Eingeloggt bleiben<input type="checkbox" name="" class="" value="">
<span class="redmark"></span>
</label>
<div class="login_btn_wrapper">
<input type="hidden" name="redirect_to" value="/b2b-login/">
<div class="login-btn"><input id="wp-submit" type="submit" value="Login" name="wp-submit"></div><div class="reset_password"><a>Passwort vergessen</a></div>
</div>
</form>
<h3>Noch kein Gratis-Account?</h3>
<div class="create_account">Account erstellen</div>
<div class="create-account-desc"><p>Privatsphäre und Datenschutz ist uns wichtig. Wir geben keine Informationen weiter.</p></div>
<?php */?>

 
<?php echo do_shortcode( "[frm-login show_labels='0' username_placeholder='E-Mail-Adresse' password_placeholder='Passwort' label_remember='Eingeloggt bleiben' remember='1' label_log_in='Login'  show_lost_password='1' label_lost_password='Passwort vergessen' class_submit='b2b-login-submit' redirect='/b2b-login/']" );?>

<h3>Noch kein Gratis-Account?</h3>
<div class="create_account" onclick="openRegPoppup()">Account erstellen</div>
<div class="create-account-desc"><p>Privatsphäre und Datenschutz ist uns wichtig. Wir geben keine Informationen weiter.</p></div>

</div>
</div>
<div class="overlay hide"></div>
<div class="regMenu regWindow hide">
<div class="close_warap"><span class="filter_close" onclick="closeReg()"></span>   </div>
<?php echo do_shortcode( "[formidable id=4]"); ?>
</div>

<div class="resetMenu resetWindow hide">
<div class="close_warap"><span class="filter_close" onclick="closeResetReg()"></span>   </div>
<?php echo do_shortcode( "[frm-reset-password show_labels='0' lostpass_button='Neues Passwort anfordern' resetpass_button='Passwort zurücksetzen' class='reset-frm' ]" );?>
</div>
<?php
get_footer();