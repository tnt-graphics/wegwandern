<?php
/**
 * Table of Contents:
 *
 * 1.0 - Enqeue stylesheets
 * 2.0 - Enqeue JavaScripts
 * ----------------------------------------------------------------------------
 */
function wegwandern_scripts() {
	/**
	 * 1.0 - Enqeue stylesheets
	 * ----------------------------------------------------------------------------
	 */
	wp_enqueue_style( 'custom-css', get_template_directory_uri() . '/css/custom.css', false, _S_VERSION, 'all' );
	wp_enqueue_style( 'ol-css', get_template_directory_uri() . '/lib/ol@v7.1.0/ol.css', false, _S_VERSION, 'all' );
	wp_enqueue_style( 'ol-ext-css', get_template_directory_uri() . '/lib/ol-ext/ol-ext.css', false, _S_VERSION, 'all' );
	wp_enqueue_style( 'jquery-ui-css', '//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css', false, _S_VERSION, 'all' );
	wp_enqueue_style( 'font-awesome-min-css', get_template_directory_uri() . '/css/font-awesome.min.css', false, _S_VERSION, 'all' );
	wp_enqueue_style( 'owl-carousel-min-css', get_template_directory_uri() . '/css/owl.carousel.min.css', false, _S_VERSION, 'all' );

	/* Owl Carousel 2 css */
	wp_enqueue_style( 'owl-carousel-default-css', get_template_directory_uri() . '/lib/owl-carousel2/owl.theme.default.min.css', false, _S_VERSION, 'all' );
	wp_enqueue_style( 'owl-carousel-min-css', get_template_directory_uri() . '/lib/owl-carousel2/owl.carousel.min.css', false, _S_VERSION, 'all' );

	wp_enqueue_style( 'lightgallery-bundle-css', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/css/lightgallery-bundle.min.css', false, _S_VERSION, 'all' );

	/* Select 2 css */
	wp_enqueue_style( 'select2-style', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', false, _S_VERSION, 'all' );

	/**
	 * 2.0 - Enqeue JavaScripts
	 * ----------------------------------------------------------------------------
	 */
	wp_enqueue_script( 'wegw-script-js', get_template_directory_uri() . '/js/wegw-scripts.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'weg-map-script-js', get_template_directory_uri() . '/js/wegw-map-scripts.js', array(), _S_VERSION, true );

	wp_enqueue_script( 'admin-script-js', get_template_directory_uri() . '/js/admin.js', array(), _S_VERSION, false );
	wp_localize_script(
		'admin-script-js',
		'ajax_object',
		array(
			'ajax_url'   => admin_url( 'admin-ajax.php' ),
			'ajax_nonce' => wp_create_nonce( 'ajax-nonce' ),

		)
	);

	wp_enqueue_script( 'custom-js', get_template_directory_uri() . '/js/custom.js', array(), _S_VERSION, true );

	wp_enqueue_script( 'ol-js', get_template_directory_uri() . '/lib/ol@v7.1.0/ol.js', array(), _S_VERSION, false );
	wp_enqueue_script( 'ol-ext-js', get_template_directory_uri() . '/lib/ol-ext/ol-ext.min.js', array(), _S_VERSION, false );
	wp_enqueue_script( 'ol-proj4-js', get_template_directory_uri() . '/lib/ol-ext/proj4.js', array(), _S_VERSION, false );
	wp_enqueue_script( 'ol-elevation-d3', 'https://d3js.org/d3.v4.js', array(), _S_VERSION, false );
	wp_enqueue_script( 'filesaver-js', get_template_directory_uri() . '/lib/jspdf/1.3.2/FileSaver.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'jspdf-js', get_template_directory_uri() . '/lib/jspdf/1.3.2/jspdf.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'jquery-ui-js', 'https://code.jquery.com/ui/1.13.2/jquery-ui.js', array(), _S_VERSION, false );
	wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'jquery-cookie-js', get_template_directory_uri() . '/js/jquery.cookie.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'jquery.ui.touch-punch', '//cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'owl-carousel-min-js', get_template_directory_uri() . '/js/owl.carousel.min.js', array(), _S_VERSION, true );

	/* Owl Carousel 2 js */
	wp_enqueue_script( 'owl-carousel-js', get_template_directory_uri() . '/lib/owl-carousel2/owl.carousel.min.js', array(), _S_VERSION, true );

	/* Lightgallery js */
	wp_enqueue_script( 'lg-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/lightgallery.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-autoplay-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/autoplay/lg-autoplay.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-fullscreen-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/fullscreen/lg-fullscreen.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-video-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/video/lg-video.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-comment-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/comment/lg-comment.umd.min.js', array(), _S_VERSION, true );

	/* Lightgallert assets */

	wp_enqueue_style( 'lightgallery-css', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/css/lightgallery.min.css', false, _S_VERSION, 'all' );
	wp_enqueue_script( 'lg-thumbnail-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/thumbnail/lg-thumbnail.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-zoom-umd-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/zoom/lg-zoom.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-hash-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/hash/lg-hash.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-medium-zoom-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/mediumZoom/lg-medium-zoom.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-pager-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/pager/lg-pager.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-relative-caption-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/relativeCaption/lg-relative-caption.umd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'lg-vimeo-thumbnail-umd-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/plugins/vimeoThumbnail/lg-vimeo-thumbnail.umd.min.js', array(), _S_VERSION, true );

	/* Select 2 js */
	wp_enqueue_script( 'select2-script', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array(), _S_VERSION, true );
}

add_action( 'wp_enqueue_scripts', 'wegwandern_scripts' );

/**
 * Enqueue Swisstopo map style & script to admin
 *
 * @param string $hook parameter.
 */
function weg_admin_enqueue_scripts( $hook ) {
	wp_enqueue_style( 'weg_admin_map_style', get_template_directory_uri() . '/lib/ol@v7.1.0/ol.css', false, '1.0.0' );
	wp_enqueue_script( 'weg_admin_map_script', get_template_directory_uri() . '/lib/ol@v7.1.0/ol.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'weg_admin_map_elevation_d3', 'https://d3js.org/d3.v4.js', array(), _S_VERSION, true );
}

add_action( 'admin_enqueue_scripts', 'weg_admin_enqueue_scripts' );

/**
 * Enqueue jquery for admin logged out.
 */
function wegw_jquery_init() {
	if ( ! is_admin() ) {
		wp_deregister_script( 'jquery' );

		// Load the copy of jQuery that comes with WordPress
		// The last parameter set to TRUE states that it should be loaded
		// in the footer.
		wp_register_script( 'jquery', '/wp-includes/js/jquery/jquery.min.js', false, '3.6.1', false );

		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'admin-script-js' );
	}
}
add_action( 'init', 'wegw_jquery_init' );

function wegw_gutenberg_style() {
	wp_enqueue_script( 'ff-editor-script', get_template_directory_uri() . '/js/my-editor-script.js', array(), microtime(), true );
}
add_action( 'enqueue_block_editor_assets', 'wegw_gutenberg_style' );